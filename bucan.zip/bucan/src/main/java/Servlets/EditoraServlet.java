/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlets;

import DAO.ContactoDAO;
import DAO.EditoraDAO;
import DAO.EnderecoDAO;
import Modelo.Contacto;
import Modelo.Editora;
import Modelo.Endereco;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "EditoraServlet", urlPatterns = {"/EditoraServlet"})
public class EditoraServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String cadastro = request.getParameter("cadastro");
        String editar = request.getParameter("editar");
        String eliminar = request.getParameter("eliminar");
        
        String nome = request.getParameter("nome");
        String contacto = request.getParameter("contacto");
        String endereco = request.getParameter("endereco");
        
        EditoraDAO editora = new EditoraDAO();
        
        //Cadastro da Editora
        if( cadastro != null && cadastro.equals("true")){
            
            ContactoDAO cont = new ContactoDAO();
            cont.cadastrarContacto(new Contacto(contacto));
            
            EnderecoDAO ende = new EnderecoDAO();
            ende.cadastrarEndereco(new Endereco(endereco));
            
            int fk_contacto = cont.pegarUltimoContacto().getPk_contacto();
            int fk_endereco = ende.pegarUltimoEndereco().getPk_endereco();
            
            editora.cadastrarEditora(new Editora(fk_contacto, fk_endereco, nome));
            
        }
        
        //Editar Editora
        if( editar != null && editar.equals("true")){
            
            String novo = request.getParameter("novo-nome");
            String pk = request.getParameter("pk");
            
            int pk_editora = Integer.parseInt(pk);
            
            editora.editarEditora(pk_editora, novo);
            
        }
        
        //Eliminar Editora
        if( eliminar != null && eliminar.equals("true")){
            String pk = request.getParameter("pk");
            int pk_editora = Integer.parseInt(pk);
            
            editora.eliminarEditora(pk_editora);
        }
        
        response.sendRedirect("admin.jsp");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
