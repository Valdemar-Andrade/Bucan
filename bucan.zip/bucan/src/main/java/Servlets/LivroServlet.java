/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlets;

import DAO.LivroDAO;
import Modelo.Livro;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "LivroServlet", urlPatterns = {"/LivroServlet"})
public class LivroServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String cadastro = request.getParameter("cadastro");
        String editar = request.getParameter("editar");
        String eliminar = request.getParameter("eliminar");
        String pesquisa = request.getParameter("pesquisa");
        
        LivroDAO livro = new LivroDAO();

        //Realizar o cadastro do Livro
        if( cadastro != null && cadastro.equals("true")){
            String titulo = request.getParameter("titulo");
            String autor = request.getParameter("autor");
            String ano = request.getParameter("ano_publicacao");
            String editora = request.getParameter("editora");
            String categoria = request.getParameter("categoria");
            String quantidade = request.getParameter("quantidade");
            String descricao = request.getParameter("descricao");
            
            int fk_categoria = Integer.parseInt(categoria);
            int fk_editora = Integer.parseInt(editora);
            int ano_publ = Integer.parseInt(ano);
            int quanti = Integer.parseInt(quantidade);
            
            livro.cadastrarLivro(new Livro(fk_categoria, fk_editora, ano_publ, quanti, titulo, descricao, autor));
        }
        
        //Editar Livro
        if( editar != null && editar.equals("true")){
            String novo = request.getParameter("novo-nome");
            String pk = request.getParameter("pk");
            
            int pk_livro = Integer.parseInt(pk);
            
            livro.editarLivro(pk_livro, novo);
        }
        
        //Eliminar Livro
        if( eliminar != null && eliminar.equals("true")){
            String pk = request.getParameter("pk");
            int pk_livro = Integer.parseInt(pk);
            
            livro.eliminarLivro(pk_livro);
        }
        
        //Pesquisar
        if( pesquisa != null && pesquisa.equals("true")){
            String texto = request.getParameter("texto");
            
            
        }
        
        response.sendRedirect("admin.jsp");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
