/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlets;

import DAO.LoginDAO;
import DAO.PessoaDAO;
import Modelo.Login;
import Modelo.Perfil;
import Modelo.Sessao;
import java.io.IOException;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");
        
        LoginDAO loginDao = new LoginDAO();
        
        Login login = loginDao.verificarLogin(email, senha);
        
        //Conta existe
        if(login.getEmail() != null && login.getSenha() != null){
            
            //
            Perfil perfil = new PessoaDAO().getPerfilDeLogin(login.getPk_login());
            Perfil perfilFuncionario = new PessoaDAO().getPerfilDeLoginFuncionario(login.getPk_login());
            
            //nivel do usuario Admin
            if(login.getFk_tipo_login() == 1){
                Sessao.tipoUsuario = 1;
                Sessao.loginID = login.getPk_login();
                
                response.sendRedirect("admin.jsp");
            }
            
            //nivel do usuario Leitor
            if(login.getFk_tipo_login() == 2){
                Sessao.nomeUsuario = perfil.getNome();
                Sessao.tipoUsuario = 2;
                Sessao.loginID = login.getPk_login();
                
                response.sendRedirect("home.jsp");
            }
            
            //nivel do usuario Balconista
            if(login.getFk_tipo_login() == 3){
                Sessao.nomeUsuario = perfilFuncionario.getNome();
                Sessao.tipoUsuario = 3;
                Sessao.loginID = login.getPk_login();
                
                response.sendRedirect("emprestar-livro-funcionario.jsp");
            }
        }else{
            //Conta nao existe
            String mensagemErro = "Usuario ou senha invalidos";
            response.sendRedirect("index.jsp?erro=" + URLEncoder.encode(mensagemErro, "UTF-8"));
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
