/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlets;

import DAO.LeitorDAO;
import DAO.LoginDAO;
import DAO.RequisicaoEmprestimoDAO;
import Modelo.RequisicaoEmprestimo;
import Modelo.Sessao;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Calendar;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "RequisicaoEmprestimoServlet", urlPatterns = { "/RequisicaoEmprestimoServlet" })
public class RequisicaoEmprestimoServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest( HttpServletRequest request, HttpServletResponse response )
            throws ServletException, IOException {

        String confirmar = request.getParameter( "confirmar" );
        String negar = request.getParameter( "rejeitado" );
        String solicitar = request.getParameter( "solicitar" );
        String solicitarFuncionario = request.getParameter( "solicitar-funcionario" );
        String devolvido = request.getParameter( "devolvido" );

        //JOptionPane.showMessageDialog(null, "Entrou: " + confirmar + " - " + negar + " - " + solicitar);
        RequisicaoEmprestimoDAO requisicaoDao = new RequisicaoEmprestimoDAO();

        //
        if ( solicitarFuncionario != null && solicitarFuncionario.equals( "solicitar-funcionario" ) ) {

            String pk_livro = request.getParameter( "pk_livro" );
            String estado = request.getParameter( "estado" );
            String fk_funcio = request.getParameter( "fk_funcionario" );
            String data_retirada = request.getParameter( "data-retirada" );
            String numero = request.getParameter( "numero_estudante" );
            String data_devolucao = data_retirada;
            
            LeitorDAO leitorDao = new LeitorDAO();
            
            if(requisicaoDao.limiteDeEmprestimosFoiAtingido( numero)){
                
                String erro = "O limite de emprestimos foi atingido para este leitor (" + numero + ") 2 livros Max";
                response.sendRedirect( "emprestar-livro-funcionario.jsp?erro=" + erro );
                
            }else if( leitorDao.isLeitorLocal( Sessao.loginID ) ){
                int fk_livro = Integer.parseInt( pk_livro );
            
                int fk_funcionario = requisicaoDao.getPkFuncionarioDeLoginID( Integer.parseInt( fk_funcio ) );

                int fk_leitor = new LeitorDAO().getPkLeitorFromNumeroEstudante( numero );

                // Converter java.sql.Date para java.util.Date
                java.util.Date utilDate = new java.util.Date( Date.valueOf( data_devolucao ).getTime() );

                // Usar Calendar para adicionar dias
                Calendar calendar = Calendar.getInstance();
                calendar.setTime( utilDate );
                calendar.add( Calendar.DAY_OF_MONTH, 3 ); // Adicionar 3 dias

                // Converter de volta para java.sql.Date
                java.sql.Date dataDevolucao = new java.sql.Date( calendar.getTime().getTime() );

                RequisicaoEmprestimo re = new RequisicaoEmprestimo( fk_livro, fk_leitor, fk_funcionario, estado, Date.valueOf( data_retirada ), dataDevolucao );

                //JOptionPane.showMessageDialog( null, "Requisicao> " + re.toString());

                requisicaoDao.cadastrarRequisicaoEmprestimo( re );

                //----------------- Confirmar -------------------

                int pk_requisicao = requisicaoDao.getPkUltimaRequisicaoAceite();

                String qtt = request.getParameter( "qtt" );

                int quantidade = Integer.parseInt( qtt );

                requisicaoDao.confirmarEmprestimo( pk_requisicao, fk_funcionario, quantidade, fk_livro );

                response.sendRedirect( "emprestar-livro-funcionario.jsp" );
            }else{
                String erro = "O Leitor (" + numero + ") nao pertence a instituicao";
                response.sendRedirect( "emprestar-livro-funcionario.jsp?erro=" + erro );
            }

        }

        //Confirmar a requisicao
        if ( confirmar != null && confirmar.equals( "aceite" ) ) {

            String pk_req = request.getParameter( "pk_requisicao" );
            String qtt = request.getParameter( "qtt" );
            String pk_login = request.getParameter( "pk_login" );
            String pk_liv = request.getParameter( "pk_livro" );

            int pk_requisicao = Integer.parseInt( pk_req );
            int quantidade = Integer.parseInt( qtt );
            int pk_log = Integer.parseInt( pk_login );
            int pk_livro = Integer.parseInt( pk_liv );

            int fk_funcionario = requisicaoDao.getPkFuncionarioDeLoginID( pk_log );

            requisicaoDao.confirmarEmprestimo( pk_requisicao, fk_funcionario, quantidade, pk_livro );

            response.sendRedirect( "gerenciar-emprestimo-funcionario.jsp" );

        }

        if ( negar != null && negar.equals( "rejeitado" ) ) {

            String pk_req = request.getParameter( "pk_requisicao" );
            String pk_login = request.getParameter( "pk_login" );

            int pk_requisicao = Integer.parseInt( pk_req );
            int pk_log = Integer.parseInt( pk_login );

            int fk_funcionario = requisicaoDao.getPkFuncionarioDeLoginID( pk_log );

            requisicaoDao.negarEmprestimo( pk_requisicao, fk_funcionario );

            response.sendRedirect( "gerenciar-emprestimo-funcionario.jsp" );

        }

        if ( solicitar != null && solicitar.equals( "solicitar" ) ) {
            String pk_livro = request.getParameter( "pk_livro" );
            String login = request.getParameter( "fk_leitor" );
            String estado = request.getParameter( "estado" );
            String data_retirada = request.getParameter( "data-retirada" );
            String data_devolucao = data_retirada;
            
            String estudanteLocal = request.getParameter( "estudanteLocal");

            int fk_livro = Integer.parseInt( pk_livro );
            int loginID = Integer.parseInt( login );

            //int pk_pessoa = new LoginDAO().getPkPessoaFromLoginID(loginID);
            int fk_leitor = new LoginDAO().getPkLeitorFromLoginID( loginID );
            
            if(requisicaoDao.limiteDeEmprestimosFoiAtingido( fk_leitor ) ){
                
                if(estudanteLocal != null && estudanteLocal.equalsIgnoreCase( "false")){
                    response.sendRedirect( "emprestar-livro.jsp" );
                }
                
                String erro = "Atingiste o teu limite de Emprestimos de 2 livros";
                response.sendRedirect( "emprestar-livro.jsp?erro=" + erro );
                
            }else{
                // Converter java.sql.Date para java.util.Date
                java.util.Date utilDate = new java.util.Date( Date.valueOf( data_devolucao ).getTime() );

                // Usar Calendar para adicionar dias
                Calendar calendar = Calendar.getInstance();
                calendar.setTime( utilDate );
                calendar.add( Calendar.DAY_OF_MONTH, 3 ); // Adicionar 3 dias

                // Converter de volta para java.sql.Date
                java.sql.Date dataDevolucao = new java.sql.Date( calendar.getTime().getTime() );

                requisicaoDao.cadastrarRequisicaoEmprestimo( new RequisicaoEmprestimo( fk_livro, fk_leitor, 0, estado, Date.valueOf( data_retirada ), dataDevolucao ) );

                response.sendRedirect( "emprestar-livro.jsp" );
            }
            
        }

        if ( devolvido != null && devolvido.equals( "devolvido" ) ) {

            String pk_req = request.getParameter( "pk_requisicao" );
            String qtt = request.getParameter( "qtt" );
            String data_devo = request.getParameter( "data-devolucao" );
            String pk_liv = request.getParameter( "pk_livro");

            int pk_requisicao = Integer.parseInt( pk_req );
            int quantidade = Integer.parseInt( qtt );
            int pk_livro = Integer.parseInt( pk_liv );

            Date data_devolucao = Date.valueOf( data_devo );

            LocalDate dataAtual = LocalDate.now();
            LocalDate dataDevolucao = data_devolucao.toLocalDate();

            //Se a data atual e posterior a data que deveria ser devolvido olivro
            //Logo, livro devolvido com atraso
            if ( dataAtual.isAfter( dataDevolucao ) ) {
                requisicaoDao.devolverEmprestimoAtrasado(pk_requisicao, quantidade, pk_livro );
            }
            else {
                //Esta dentro do prazo de devolucao do livro
                requisicaoDao.devolverEmprestimo( pk_requisicao, quantidade, pk_livro );
            }

            response.sendRedirect( "devolucao-livro-funcionario.jsp" );

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet( HttpServletRequest request, HttpServletResponse response )
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest( request, response );
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost( HttpServletRequest request, HttpServletResponse response )
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest( request, response );
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
