/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlets;

import DAO.ContactoDAO;
import DAO.LeitorDAO;
import DAO.LoginDAO;
import DAO.PessoaDAO;
import Modelo.Contacto;
import Modelo.Leitor;
import Modelo.Login;
import Modelo.Pessoa;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "CriarContaServlet", urlPatterns = {"/CriarContaServlet"})
public class CriarContaServlet extends HttpServlet {

    private String mensagemErro = "Preencha Corretamente os campos: ";
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String faculdade = request.getParameter("faculdade");
        String curso = request.getParameter("curso");
        String numeroEstudante = request.getParameter("numeroEstudante");
        String senha = request.getParameter("senha");
        String estudanteLocal = request.getParameter("estudanteLocal");
        String emailUniversitario = request.getParameter("emailUniversitario");
        String numeroBI = request.getParameter("numeroBI");
        String contacto = request.getParameter("contacto");
        
        boolean isEstudanteLocal = false;
        boolean validarDataNascimento = false;
        
        if( emailUniversitario != null && !emailUniversitario.trim().isEmpty())
            isEstudanteLocal = true;
        
        int fk_curso = 0;

        Date dataNascimento = null;

        //Converter de string para date
        try {
            String data = request.getParameter("dataNascimento");
            dataNascimento = Date.valueOf(data);
            
            LocalDate dataAtual = LocalDate.now();
            int anoAtual = dataAtual.getYear();
            
            Calendar calendar = Calendar.getInstance();
            calendar.setTime( dataNascimento );
            int anoNascimento = calendar.get( Calendar.YEAR );
            
            //Se tiver de 17 ou mais
            if ( (anoAtual - anoNascimento) >= 17 ){
                validarDataNascimento = true;
            }else validarDataNascimento = false;
            
            fk_curso = Integer.parseInt(curso);

        } catch ( NullPointerException ex) {
            Logger.getLogger(CriarContaServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (validado(nome, email, faculdade, curso, numeroEstudante, senha, numeroBI, contacto, validarDataNascimento)) {
            
            //Cadastro do Login
            LoginDAO login = new LoginDAO();
            login.cadastrarLogin(new Login(2, email, senha));
            
            int fk_login = login.pegarUltimoLogin().getPk_login();
            
            //Cadastro do Contacto
            ContactoDAO contactoDao = new ContactoDAO();
            contactoDao.cadastrarContacto(new Contacto(contacto));
            
            int fk_contacto = contactoDao.pegarUltimoContacto().getPk_contacto();
            
            //Cadastro da Pessoa
            PessoaDAO pessoa = new PessoaDAO();
            pessoa.cadastrarPessoa(new Pessoa(nome, numeroBI, dataNascimento, fk_contacto));
            
            int fk_pessoa = pessoa.getPkUltimaPessoa();
            
            //Cadastro do Leitor
            LeitorDAO leitor = new LeitorDAO();
            leitor.cadastrarLeitor(new Leitor(numeroEstudante, emailUniversitario, isEstudanteLocal, fk_pessoa, fk_curso, fk_login));
            
            response.sendRedirect("index.jsp");
        }else{
            //Campos invalidos
            response.sendRedirect("criar-conta.jsp?erro=" + mensagemErro + "&nome=" + nome + "&email=" + email + "&num=" + numeroEstudante + "&bi=" + numeroBI + "&tel=" + contacto);
        }

    }
    
    private boolean validado(String nome, String email, String faculdade, String curso, String numeroEst, String senha, String numeroBI, String contacto, boolean validarDataNascimento){
        boolean temErro = false;
        
        if(nome.trim().isEmpty()){
            mensagemErro += "Nome ";
            temErro = true;
        }
        
        if(email.trim().isEmpty()){
            mensagemErro += "Email ";
            temErro = true;
        }
        
        if(faculdade.trim().isEmpty()){
            mensagemErro += "Faculdade ";
            temErro = true;
        }
        
        if(curso.trim().isEmpty()){
            mensagemErro += "Curso ";
            temErro = true;
        }
        
        if(numeroEst.trim().isEmpty() || numeroEst.trim().length() != 10){
            mensagemErro += "Numero de Estudante ";
            temErro = true;
        }
        
        if(senha.trim().isEmpty()){
            mensagemErro += "Senha ";
            temErro = true;
        }
        
        if(numeroBI.trim().isEmpty() || numeroBI.trim().length() != 14){
            mensagemErro += "BI ";
            temErro = true;
        }
        
        if(contacto.trim().isEmpty() || contacto.trim().length() != 9){
            mensagemErro += "Telefone ";
            temErro = true;
        }
        
        if(!validarDataNascimento){
            mensagemErro += "Data Nascimento ";
            temErro = true;
        }
        
        return !temErro;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
