/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class ResultadoPesquisaHome {
    
    private String titulo, autor, descricao;

    public ResultadoPesquisaHome() {
    }

    public ResultadoPesquisaHome( String titulo, String autor, String descricao ) {
        this.titulo = titulo;
        this.autor = autor;
        this.descricao = descricao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo( String titulo ) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor( String autor ) {
        this.autor = autor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao( String descricao ) {
        this.descricao = descricao;
    }
    
    
    
}
