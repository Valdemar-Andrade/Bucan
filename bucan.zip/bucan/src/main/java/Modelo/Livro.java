/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Livro {
    
    private int pk_livro, fk_categoria, fk_editora, ano_publicacao, quantidade;
    private String titulo, descricao, autor;

    public Livro() {
    }

    public Livro(int pk_livro, int fk_categoria, int fk_editora, int ano_publicacao, int quantidade, String titulo, String descricao, String autor) {
        this.pk_livro = pk_livro;
        this.fk_categoria = fk_categoria;
        this.fk_editora = fk_editora;
        this.ano_publicacao = ano_publicacao;
        this.quantidade = quantidade;
        this.titulo = titulo;
        this.descricao = descricao;
        this.autor = autor;
    }

    public Livro(int fk_categoria, int fk_editora, int ano_publicacao, int quantidade, String titulo, String descricao, String autor) {
        this.fk_categoria = fk_categoria;
        this.fk_editora = fk_editora;
        this.ano_publicacao = ano_publicacao;
        this.quantidade = quantidade;
        this.titulo = titulo;
        this.descricao = descricao;
        this.autor = autor;
    }

    public int getPk_livro() {
        return pk_livro;
    }

    public void setPk_livro(int pk_livro) {
        this.pk_livro = pk_livro;
    }

    public int getFk_categoria() {
        return fk_categoria;
    }

    public void setFk_categoria(int fk_genero) {
        this.fk_categoria = fk_genero;
    }

    public int getFk_editora() {
        return fk_editora;
    }

    public void setFk_editora(int fk_editora) {
        this.fk_editora = fk_editora;
    }

    public int getAno_publicacao() {
        return ano_publicacao;
    }

    public void setAno_publicacao(int ano_publicacao) {
        this.ano_publicacao = ano_publicacao;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    @Override
    public String toString() {
        return "Livro{" + "pk_livro=" + pk_livro + ", fk_categoria=" + fk_categoria + ", fk_editora=" + fk_editora + ", ano_publicacao=" + ano_publicacao + ", quantidade=" + quantidade + ", titulo=" + titulo + ", descricao=" + descricao + ", autor=" + autor + '}';
    }
    
}
