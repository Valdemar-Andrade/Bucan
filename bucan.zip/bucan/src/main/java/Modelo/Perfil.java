/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Perfil {
    
    private String nome, numeroEstudante, curso, email;
    private int pk_pessoa, loginID, fk_leitor;

    public Perfil() {
    }

    public Perfil(String nome, String numeroEstudante, String curso, int pk_pessoa, int loginID) {
        this.nome = nome;
        this.numeroEstudante = numeroEstudante;
        this.curso = curso;
        this.pk_pessoa = pk_pessoa;
        this.loginID = loginID;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNumeroEstudante() {
        return numeroEstudante;
    }

    public void setNumeroEstudante(String numeroEstudante) {
        this.numeroEstudante = numeroEstudante;
    }

    public int getPk_pessoa() {
        return pk_pessoa;
    }

    public void setPk_pessoa(int pk_pessoa) {
        this.pk_pessoa = pk_pessoa;
    }

    public int getLoginID() {
        return loginID;
    }

    public void setLoginID(int loginID) {
        this.loginID = loginID;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public int getFk_leitor() {
        return fk_leitor;
    }

    public void setFk_leitor( int fk_leitor ) {
        this.fk_leitor = fk_leitor;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail( String email ) {
        this.email = email;
    }
    
    
    
}
