/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class RelatorioEmprestimo {
    
    private String funcionario, leitor, livro;
    private int total;

    public RelatorioEmprestimo() {
    }

    public RelatorioEmprestimo( String funcionario, String leitor, String livro, int total ) {
        this.funcionario = funcionario;
        this.leitor = leitor;
        this.livro = livro;
        this.total = total;
    }

    public String getFuncionario() {
        return funcionario;
    }

    public void setFuncionario( String funcionario ) {
        this.funcionario = funcionario;
    }

    public String getLeitor() {
        return leitor;
    }

    public void setLeitor( String leitor ) {
        this.leitor = leitor;
    }

    public String getLivro() {
        return livro;
    }

    public void setLivro( String livro ) {
        this.livro = livro;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal( int total ) {
        this.total = total;
    }
    
    
    
}
