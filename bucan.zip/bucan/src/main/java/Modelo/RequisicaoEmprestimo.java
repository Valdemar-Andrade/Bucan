/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Date;

/**
 *
 * @author valdemar
 */
public class RequisicaoEmprestimo {
    
    private int pk_requisicao, fk_livro, fk_leitor, fk_funcionario;
    private String estado;
    private Date data_retirada, data_devolucao;

    public RequisicaoEmprestimo() {
    }

    public RequisicaoEmprestimo(int pk_requisicao, int fk_livro, int fk_leitor, int fk_funcionario, String estado, Date data_retirada, Date data_devolucao) {
        this.pk_requisicao = pk_requisicao;
        this.fk_livro = fk_livro;
        this.fk_leitor = fk_leitor;
        this.fk_funcionario = fk_funcionario;
        this.estado = estado;
        this.data_retirada = data_retirada;
        this.data_devolucao = data_devolucao;
    }

    public RequisicaoEmprestimo(int fk_livro, int fk_leitor, int fk_funcionario, String estado, Date data_retirada, Date data_devolucao) {
        this.fk_livro = fk_livro;
        this.fk_leitor = fk_leitor;
        this.fk_funcionario = fk_funcionario;
        this.estado = estado;
        this.data_retirada = data_retirada;
        this.data_devolucao = data_devolucao;
    }

    public int getPk_requisicao() {
        return pk_requisicao;
    }

    public void setPk_requisicao(int pk_requisicao) {
        this.pk_requisicao = pk_requisicao;
    }

    public int getFk_livro() {
        return fk_livro;
    }

    public void setFk_livro(int fk_livro) {
        this.fk_livro = fk_livro;
    }

    public int getFk_leitor() {
        return fk_leitor;
    }

    public void setFk_leitor(int fk_leitor) {
        this.fk_leitor = fk_leitor;
    }

    public int getFk_funcionario() {
        return fk_funcionario;
    }

    public void setFk_funcionario(int fk_funcionario) {
        this.fk_funcionario = fk_funcionario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Date getData_retirada() {
        return data_retirada;
    }

    public void setData_retirada(Date data_retirada) {
        this.data_retirada = data_retirada;
    }

    public Date getData_devolucao() {
        return data_devolucao;
    }

    public void setData_devolucao(Date data_devolucao) {
        this.data_devolucao = data_devolucao;
    }

    @Override
    public String toString() {
        return "RequisicaoEmprestimo{" + "pk_requisicao=" + pk_requisicao + ", fk_livro=" + fk_livro + ", fk_leitor=" + fk_leitor + ", fk_funcionario=" + fk_funcionario + ", estado=" + estado + ", data_retirada=" + data_retirada + ", data_devolucao=" + data_devolucao + '}';
    }

    
    
}
