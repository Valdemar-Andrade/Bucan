/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Date;

/**
 *
 * @author valdemar
 */
public class Pessoa {
    
    private String nome, numeroBI;
    private Date dataNascimento;
    private int pk_pessoa, fk_contacto;

    public Pessoa(String nome, String numeroBI, Date dataNascimento, int fk_contacto) {
        this.nome = nome;
        this.numeroBI = numeroBI;
        this.dataNascimento = dataNascimento;
        this.fk_contacto = fk_contacto;
    }
    
    public Pessoa(){
        
    }

    public int getPk_pessoa() {
        return pk_pessoa;
    }

    public int getFk_contacto() {
        return fk_contacto;
    }

    public void setFk_contacto(int fk_contacto) {
        this.fk_contacto = fk_contacto;
    }

    public void setPk_pessoa(int pk_pessoa) {
        this.pk_pessoa = pk_pessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNumeroBI() {
        return numeroBI;
    }

    public void setNumeroBI(String numeroBI) {
        this.numeroBI = numeroBI;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    
    
    
}
