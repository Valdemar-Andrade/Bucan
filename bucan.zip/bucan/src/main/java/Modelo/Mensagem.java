/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Mensagem {
    
    private int pk_mensagem, fk_leitor;
    private String mensagem, email, nome, numero_estudante;

    public int getPk_mensagem() {
        return pk_mensagem;
    }

    public void setPk_mensagem( int pk_mensagem ) {
        this.pk_mensagem = pk_mensagem;
    }

    public int getFk_leitor() {
        return fk_leitor;
    }

    public void setFk_leitor( int fk_leitor ) {
        this.fk_leitor = fk_leitor;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem( String mensagem ) {
        this.mensagem = mensagem;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail( String email ) {
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public void setNome( String nome ) {
        this.nome = nome;
    }

    public String getNumero_estudante() {
        return numero_estudante;
    }

    public void setNumero_estudante( String numero_estudante ) {
        this.numero_estudante = numero_estudante;
    }

    @Override
    public String toString() {
        return "Mensagem{" + "pk_mensagem=" + pk_mensagem + ", fk_leitor=" + fk_leitor + ", mensagem=" + mensagem + ", email=" + email + ", nome=" + nome + '}';
    }
    
    
    
}
