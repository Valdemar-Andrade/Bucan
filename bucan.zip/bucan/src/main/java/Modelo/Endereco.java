/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Endereco {
    
    private int pk_endereco;
    private String descricao;

    public Endereco() {
    }

    public Endereco(int pk_endereco, String descricao) {
        this.pk_endereco = pk_endereco;
        this.descricao = descricao;
    }

    public Endereco(String descricao) {
        this.descricao = descricao;
    }

    public int getPk_endereco() {
        return pk_endereco;
    }

    public void setPk_endereco(int pk_endereco) {
        this.pk_endereco = pk_endereco;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
