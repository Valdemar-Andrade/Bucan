/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Editora {
    
    private int pk_editora, fk_contacto, fk_endereco;
    private String nome;

    public Editora() {
    }

    public Editora(int pk_editora, int fk_contacto, int fk_endereco, String nome) {
        this.pk_editora = pk_editora;
        this.fk_contacto = fk_contacto;
        this.fk_endereco = fk_endereco;
        this.nome = nome;
    }

    public Editora(int fk_contacto, int fk_endereco, String nome) {
        this.fk_contacto = fk_contacto;
        this.fk_endereco = fk_endereco;
        this.nome = nome;
    }

    public int getFk_contacto() {
        return fk_contacto;
    }

    public void setFk_contacto(int fk_contacto) {
        this.fk_contacto = fk_contacto;
    }

    public int getFk_endereco() {
        return fk_endereco;
    }

    public void setFk_endereco(int fk_endereco) {
        this.fk_endereco = fk_endereco;
    }
    
    public int getPk_editora() {
        return pk_editora;
    }

    public void setPk_editora(int pk_editora) {
        this.pk_editora = pk_editora;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
