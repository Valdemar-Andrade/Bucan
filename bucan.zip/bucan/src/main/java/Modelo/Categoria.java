/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Categoria {
    
    private int pk_categoria;
    private String descricao;

    public Categoria() {
    }

    public Categoria(int pk_categoria, String descricao) {
        this.pk_categoria = pk_categoria;
        this.descricao = descricao;
    }
    
    public Categoria(String descricao) {
        this.descricao = descricao;
    }

    public int getPk_categoria() {
        return pk_categoria;
    }

    public void setPk_categoria(int pk_categoria) {
        this.pk_categoria = pk_categoria;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
