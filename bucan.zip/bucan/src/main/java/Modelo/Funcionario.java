/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Funcionario {
    
    private int pk_funcionario, fk_pessoa, fk_contacto, fk_endereco, fk_login;

    public Funcionario() {
    }

    public Funcionario(int pk_funcionario, int fk_pessoa, int fk_contacto, int fk_endereco, int fk_login) {
        this.pk_funcionario = pk_funcionario;
        this.fk_pessoa = fk_pessoa;
        this.fk_contacto = fk_contacto;
        this.fk_endereco = fk_endereco;
        this.fk_login = fk_login;
    }

    public Funcionario(int fk_pessoa, int fk_contacto, int fk_endereco, int fk_login) {
        this.fk_pessoa = fk_pessoa;
        this.fk_contacto = fk_contacto;
        this.fk_endereco = fk_endereco;
        this.fk_login = fk_login;
    }

    public int getPk_funcionario() {
        return pk_funcionario;
    }

    public void setPk_funcionario(int pk_funcionario) {
        this.pk_funcionario = pk_funcionario;
    }

    public int getFk_pessoa() {
        return fk_pessoa;
    }

    public void setFk_pessoa(int fk_pessoa) {
        this.fk_pessoa = fk_pessoa;
    }

    public int getFk_contacto() {
        return fk_contacto;
    }

    public void setFk_contacto(int fk_contacto) {
        this.fk_contacto = fk_contacto;
    }

    public int getFk_endereco() {
        return fk_endereco;
    }

    public void setFk_endereco(int fk_endereco) {
        this.fk_endereco = fk_endereco;
    }

    public int getFk_login() {
        return fk_login;
    }

    public void setFk_login(int fk_login) {
        this.fk_login = fk_login;
    }
    
    
    
}
