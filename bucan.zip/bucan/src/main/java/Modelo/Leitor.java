/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Leitor{
    
    private String numeroEstudante, emailUniversitario;
    private boolean ehEstudanteLocal;
    private int pk_leitor, fk_pessoa, fk_curso, fk_login;

    public Leitor(String numeroEstudante, String emailUniversitario, boolean ehEstudanteLocal, int fk_pessoa, int fk_curso, int fk_login) {
        this.numeroEstudante = numeroEstudante;
        this.emailUniversitario = emailUniversitario;
        this.ehEstudanteLocal = ehEstudanteLocal;
        this.fk_pessoa = fk_pessoa;
        this.fk_curso = fk_curso;
        this.fk_login = fk_login;
    }
    
    public Leitor(){
        
    }

    public int getFk_curso() {
        return fk_curso;
    }

    public void setFk_curso(int fk_curso) {
        this.fk_curso = fk_curso;
    }

    public int getFk_login() {
        return fk_login;
    }

    public void setFk_login(int fk_login) {
        this.fk_login = fk_login;
    }

    public int getFk_pessoa() {
        return fk_pessoa;
    }

    public void setFk_pessoa(int fk_pessoa) {
        this.fk_pessoa = fk_pessoa;
    }

    public int getPk_leitor() {
        return pk_leitor;
    }

    public void setPk_leitor(int pk_leitor) {
        this.pk_leitor = pk_leitor;
    }

    public String getNumeroEstudante() {
        return numeroEstudante;
    }

    public void setNumeroEstudante(String numeroEstudante) {
        this.numeroEstudante = numeroEstudante;
    }

    public String getEmailUniversitario() {
        return emailUniversitario;
    }

    public void setEmailUniversitario(String emailUniversitario) {
        this.emailUniversitario = emailUniversitario;
    }

    public boolean isEhEstudanteLocal() {
        return ehEstudanteLocal;
    }

    public void setEhEstudanteLocal(boolean ehEstudanteLocal) {
        this.ehEstudanteLocal = ehEstudanteLocal;
    }
    
    
    
}
