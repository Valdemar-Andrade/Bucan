/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Contacto {
    
    private String descricao;
    private int pk_contacto;
    
    public Contacto(){
        
    }

    public Contacto(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getPk_contacto() {
        return pk_contacto;
    }

    public void setPk_contacto(int pk_contacto) {
        this.pk_contacto = pk_contacto;
    }
    
}
