/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Faculdade {
    
    private int pk_faculdade;
    private String descricao;

    public Faculdade() {
    }

    public Faculdade(int pk_faculdade, String descricao) {
        this.pk_faculdade = pk_faculdade;
        this.descricao = descricao;
    }

    public int getPk_faculdade() {
        return pk_faculdade;
    }

    public void setPk_faculdade(int pk_faculdade) {
        this.pk_faculdade = pk_faculdade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
