/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Curso {
    
    private int pk_curso, fk_faculdade;
    private String descricao;

    public Curso() {
    }

    public Curso(int pk_curso, int fk_faculdade, String descricao) {
        this.pk_curso = pk_curso;
        this.fk_faculdade = fk_faculdade;
        this.descricao = descricao;
    }

    public int getPk_curso() {
        return pk_curso;
    }

    public void setPk_curso(int pk_curso) {
        this.pk_curso = pk_curso;
    }

    public int getFk_faculdade() {
        return fk_faculdade;
    }

    public void setFk_faculdade(int fk_faculdade) {
        this.fk_faculdade = fk_faculdade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
