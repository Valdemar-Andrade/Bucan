/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class Login {
    
    private int pk_login, fk_tipo_login;
    private String email, senha;

    public Login(int fk_tipo_login, String email, String senha) {
        this.fk_tipo_login = fk_tipo_login;
        this.email = email;
        this.senha = senha;
    }
    
    public Login(int pk_login, int fk_tipo_login, String email, String senha) {
        this.fk_tipo_login = fk_tipo_login;
        this.pk_login = pk_login;
        this.email = email;
        this.senha = senha;
    }

    public Login() {
        
    }

    public int getPk_login() {
        return pk_login;
    }

    public void setPk_login(int pk_login) {
        this.pk_login = pk_login;
    }

    public int getFk_tipo_login() {
        return fk_tipo_login;
    }

    public void setFk_tipo_login(int fk_tipo_login) {
        this.fk_tipo_login = fk_tipo_login;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Override
    public String toString() {
        return "Login{" + "pk_login=" + pk_login + ", fk_tipo_login=" + fk_tipo_login + ", email=" + email + ", senha=" + senha + '}';
    }
    
}
