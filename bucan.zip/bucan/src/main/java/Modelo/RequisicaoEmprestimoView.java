/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author valdemar
 */
public class RequisicaoEmprestimoView extends RequisicaoEmprestimo{
    
    private String estudante, livro, autor;
    private int disponibilidade;

    public RequisicaoEmprestimoView() {
    }

    public RequisicaoEmprestimoView(String estudante, String livro, String autor, int disponibilidade) {
        this.estudante = estudante;
        this.livro = livro;
        this.autor = autor;
        this.disponibilidade = disponibilidade;
    }

    public String getEstudante() {
        return estudante;
    }

    public void setEstudante(String estudante) {
        this.estudante = estudante;
    }

    public String getLivro() {
        return livro;
    }

    public void setLivro(String livro) {
        this.livro = livro;
    }

    public int getDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(int disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
    
    
    
}
