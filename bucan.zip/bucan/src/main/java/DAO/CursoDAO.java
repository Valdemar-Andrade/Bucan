/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Curso;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class CursoDAO {
    
    public boolean cadastrarCurso(Curso curso) {
        
        String query_insert = "INSERT INTO curso VALUES (DEFAULT, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, curso.getDescricao());
            ps.setInt(2, curso.getFk_faculdade());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarCurso(int id, String valor){
        String query = "update curso set descricao=? where pk_curso=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarCurso(int id){
        String query = "delete from curso where pk_curso=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Curso> listarCurso() {
        ArrayList<Curso> listaCurso = new ArrayList<>();
        String query = "SELECT pk_curso, descricao, fk_faculdade FROM curso";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Curso curso = new Curso();

                curso.setPk_curso(rs.getInt(1));
                curso.setDescricao(rs.getString(2));
                curso.setFk_faculdade(rs.getInt(3));

                listaCurso.add(curso);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaCurso;
    }
    
}
