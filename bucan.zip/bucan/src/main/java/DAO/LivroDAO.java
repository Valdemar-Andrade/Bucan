/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Livro;
import Modelo.LivroView;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class LivroDAO {
    
    public void cadastrarLivro(Livro livro) {

        String query_insert = "INSERT INTO livro VALUES (DEFAULT, ?, ?, ?, ?, ?, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, livro.getTitulo());
            ps.setInt(2, livro.getFk_categoria());
            ps.setInt(3, livro.getFk_editora());
            ps.setString(4, livro.getDescricao());
            ps.setInt(5, livro.getAno_publicacao());
            ps.setInt(6, livro.getQuantidade());
            ps.setString(7, livro.getAutor());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<LivroView> listarLivro() {
        ArrayList<LivroView> listaLivro = new ArrayList<>();
        String query = "SELECT pk_livro, li.titulo, ca.descricao, ed.nome, li.descricao, li.ano_publicacao, li.quantidade, li.autor FROM livro li JOIN categoria ca ON li.fk_categoria=ca.pk_categoria JOIN editora ed ON li.fk_editora=ed.pk_editora";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                LivroView livro = new LivroView();

                livro.setPk_livro(rs.getInt(1));
                livro.setTitulo(rs.getString(2));
                livro.setCategoria(rs.getString(3));
                livro.setEditora(rs.getString(4));
                livro.setDescricao(rs.getString(5));
                livro.setAno_publicacao(rs.getInt(6));
                livro.setQuantidade(rs.getInt(7));
                livro.setAutor(rs.getString(8));

                listaLivro.add(livro);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaLivro;
    }
    
    public void editarLivro(int id, String valor){
        String query = "update livro set titulo=? where pk_livro=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarLivro(int id){
        String query = "delete from livro where pk_livro=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public int totalLivros() {

        String query = "SELECT count(pk_livro) FROM livro";
        
        int total = 0;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                total = rs.getInt(1);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return total;

    }
    
}
