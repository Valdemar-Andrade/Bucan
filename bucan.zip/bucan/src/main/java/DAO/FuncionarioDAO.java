/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Funcionario;
import Modelo.FuncionarioView;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class FuncionarioDAO {
    
    public void cadastrarFuncionario(Funcionario funcionario) {

        String query_insert = "INSERT INTO funcionario VALUES (DEFAULT, ?, ?, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setInt(1, funcionario.getFk_pessoa());
            ps.setInt(2, funcionario.getFk_endereco());
            ps.setInt(3, funcionario.getFk_contacto());
            ps.setInt(4, funcionario.getFk_login());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<FuncionarioView> listarFuncionario() {
        ArrayList<FuncionarioView> listaFuncionario = new ArrayList<>();
        String query = "select pe.pk_pessoa, fu.pk_funcionario, pe.nome, co.descricao, en.descricao, pe.num_bi from funcionario fu join pessoa pe on fu.fk_pessoa=pe.pk_pessoa join endereco en on fu.fk_endereco=en.pk_endereco join contacto co on fu.fk_contacto=co.pk_contacto";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                FuncionarioView funcionario = new FuncionarioView();

                funcionario.setFk_pessoa(rs.getInt(1));
                funcionario.setPk_funcionario(rs.getInt(2));
                funcionario.setNome(rs.getString(3));
                funcionario.setContacto(rs.getString(4));
                funcionario.setEndereco(rs.getString(5));
                funcionario.setNumeroBI(rs.getString(6));
                //funcionario.setDataNascimento(rs.getString(6));

                listaFuncionario.add(funcionario);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaFuncionario;
    }

    public Funcionario pegarUltimoFuncionario() {

        Funcionario funcionario = new Funcionario();

        String query = "SELECT max(pk_funcionario) FROM funcionario";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                funcionario.setPk_funcionario(rs.getInt(1));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return funcionario;

    }

    public FuncionarioView getFuncionario(int pk_funcionario) {

        FuncionarioView funcionario = new FuncionarioView();

        String query = "select fu.pk_funcionario, pe.nome, co.descricao, en.descricao, pe.num_bi, pe.dataNascimento from funcionario fu join pessoa pe on fu.fk_pessoa=pe.pk_pessoa join endereco en on fu.fk_endereco=en.pk_endereco join contacto co on fu.fk_contacto=co.pk_contacto WHERE fu.pk_funcionario=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk_funcionario);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                funcionario.setPk_funcionario(rs.getInt(1));
                funcionario.setNome(rs.getString(2));
                funcionario.setContacto(rs.getString(3));
                funcionario.setEndereco(rs.getString(4));
                funcionario.setNumeroBI(rs.getString(5));
                funcionario.setDataNascimento(rs.getString(6));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return funcionario;
    }
    
    public void editarFuncionario(int id, String valor){
        String query = "update pessoa set nome=? where pk_pessoa=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarFuncionario(int id){
        String query = "delete from funcionario where pk_funcionario=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public int totalFuncionarios() {

        int total = 0;

        String query = "SELECT count(pk_funcionario) FROM funcionario";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                total = rs.getInt(1);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return total;

    }
    
}
