/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.RequisicaoEmprestimo;
import Modelo.RequisicaoEmprestimoView;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class RequisicaoEmprestimoDAO {

    public void cadastrarRequisicaoEmprestimo( RequisicaoEmprestimo requisicaoEmprestimo ) {

        //JOptionPane.showMessageDialog(null, "Tudo: " + requisicaoEmprestimo.toString());
        String query_insert = "INSERT INTO requisicao VALUES (DEFAULT, ?, ?, ?, ?, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query_insert );

            ps.setInt( 1, requisicaoEmprestimo.getFk_livro() );
            ps.setInt( 2, requisicaoEmprestimo.getFk_leitor() );
            ps.setInt( 3, requisicaoEmprestimo.getFk_funcionario() );
            ps.setString( 4, requisicaoEmprestimo.getEstado() );
            ps.setDate( 5, requisicaoEmprestimo.getData_retirada() );
            ps.setDate( 6, requisicaoEmprestimo.getData_devolucao() );

            ps.execute();
            ps.close();
            con.close();

        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
    }
    
    public boolean limiteDeEmprestimosFoiAtingido(String numeroEstudante){
        int total = 0;
        
        String query = "SELECT count(pk_requisicao) FROM requisicao r JOIN leitor l ON r.fk_leitor=l.pk_leitor WHERE r.estado=? AND l.numero_estudante=?";
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            
            ps.setString( 1, "aceite");
            ps.setString( 2, numeroEstudante);
            
            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                total = rs.getInt( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
        
        return total >= 2;//Limite de emprestimo 2 livros
    }
    
    public boolean limiteDeEmprestimosFoiAtingido(int fk_leitor){
        int total = 0;
        
        String query = "SELECT count(pk_requisicao) FROM requisicao r JOIN leitor l ON r.fk_leitor=l.pk_leitor WHERE r.estado=? AND l.pk_leitor=?";
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            
            ps.setString( 1, "aceite");
            ps.setInt( 2, fk_leitor);
            
            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                total = rs.getInt( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
        
        return total >= 2;//Limite de emprestimo 2 livros
    }
    
    public int getPkUltimaRequisicaoAceite(){
        RequisicaoEmprestimo re = new RequisicaoEmprestimo();
        
        int pk = 0;

        String query = "SELECT MAX(pk_requisicao) FROM requisicao WHERE estado=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            
            ps.setString( 1, "aceite");
            
            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                pk = rs.getInt( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
        
        return pk;
    }

    public ArrayList<RequisicaoEmprestimoView> listarRequisicaoEmprestimo() {
        ArrayList<RequisicaoEmprestimoView> listaRequisicao = new ArrayList<>();
        String query = "select p.nome, li.titulo, li.quantidade, r.pk_requisicao, li.autor, r.data_retirada, r.estado from requisicao r join leitor l on l.pk_leitor=r.fk_leitor join pessoa p on p.pk_pessoa=l.fk_pessoa join livro li on li.pk_livro=r.fk_livro";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );

            ResultSet rs = ps.executeQuery();

            while ( rs.next() ) {
                RequisicaoEmprestimoView requisicaoEmprestimo = new RequisicaoEmprestimoView();

                requisicaoEmprestimo.setEstudante( rs.getString( 1 ) );
                requisicaoEmprestimo.setLivro( rs.getString( 2 ) );
                requisicaoEmprestimo.setDisponibilidade( rs.getInt( 3 ) );
                requisicaoEmprestimo.setPk_requisicao( rs.getInt( 4 ) );
                requisicaoEmprestimo.setAutor( rs.getString( 5 ) );
                requisicaoEmprestimo.setData_retirada( rs.getDate( 6 ) );
                requisicaoEmprestimo.setEstado( rs.getString( 7 ) );

                listaRequisicao.add( requisicaoEmprestimo );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
        return listaRequisicao;
    }
    
    public ArrayList<RequisicaoEmprestimoView> listarRequisicaoEmprestimoPerfil(int pk_login) {
        ArrayList<RequisicaoEmprestimoView> listaRequisicao = new ArrayList<>();
        String query = "select p.nome, li.titulo, li.quantidade, r.pk_requisicao, li.autor, r.data_retirada, r.estado from requisicao r join leitor l on l.pk_leitor=r.fk_leitor join pessoa p on p.pk_pessoa=l.fk_pessoa join livro li on li.pk_livro=r.fk_livro where l.fk_login=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ps.setInt( 1, pk_login);

            ResultSet rs = ps.executeQuery();

            while ( rs.next() ) {
                RequisicaoEmprestimoView requisicaoEmprestimo = new RequisicaoEmprestimoView();

                requisicaoEmprestimo.setEstudante( rs.getString( 1 ) );
                requisicaoEmprestimo.setLivro( rs.getString( 2 ) );
                requisicaoEmprestimo.setDisponibilidade( rs.getInt( 3 ) );
                requisicaoEmprestimo.setPk_requisicao( rs.getInt( 4 ) );
                requisicaoEmprestimo.setAutor( rs.getString( 5 ) );
                requisicaoEmprestimo.setData_retirada( rs.getDate( 6 ) );
                requisicaoEmprestimo.setEstado( rs.getString( 7 ) );

                listaRequisicao.add( requisicaoEmprestimo );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
        return listaRequisicao;
    }

    public ArrayList<RequisicaoEmprestimoView> listarRequisicaoEmprestimoPendente() {
        ArrayList<RequisicaoEmprestimoView> listaRequisicao = new ArrayList<>();
        String query = "select p.nome, li.titulo, li.quantidade, r.pk_requisicao, l.numero_estudante, li.pk_livro from requisicao r join leitor l on l.pk_leitor=r.fk_leitor join pessoa p on p.pk_pessoa=l.fk_pessoa join livro li on li.pk_livro=r.fk_livro where r.estado=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ps.setString( 1, "pendente" );

            ResultSet rs = ps.executeQuery();

            while ( rs.next() ) {
                RequisicaoEmprestimoView requisicaoEmprestimo = new RequisicaoEmprestimoView();

                requisicaoEmprestimo.setEstudante( rs.getString( 1 ) );
                requisicaoEmprestimo.setLivro( rs.getString( 2 ) );
                requisicaoEmprestimo.setDisponibilidade( rs.getInt( 3 ) );
                requisicaoEmprestimo.setPk_requisicao( rs.getInt( 4 ) );
                requisicaoEmprestimo.setEstudante( requisicaoEmprestimo.getEstudante() + " (" + rs.getString( 5 ) + ")" );
                requisicaoEmprestimo.setFk_livro( rs.getInt( 6 ) );

                listaRequisicao.add( requisicaoEmprestimo );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
        return listaRequisicao;
    }

    public ArrayList<RequisicaoEmprestimoView> listarRequisicaoEmprestimoAceite() {
        ArrayList<RequisicaoEmprestimoView> listaRequisicao = new ArrayList<>();
        String query = "select p.nome, li.titulo, li.quantidade, r.pk_requisicao, l.numero_estudante, li.pk_livro, r.data_devolucao from requisicao r join leitor l on l.pk_leitor=r.fk_leitor join pessoa p on p.pk_pessoa=l.fk_pessoa join livro li on li.pk_livro=r.fk_livro where r.estado=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ps.setString( 1, "aceite" );

            ResultSet rs = ps.executeQuery();

            while ( rs.next() ) {
                RequisicaoEmprestimoView requisicaoEmprestimo = new RequisicaoEmprestimoView();

                requisicaoEmprestimo.setEstudante( rs.getString( 1 ) );
                requisicaoEmprestimo.setLivro( rs.getString( 2 ) );
                requisicaoEmprestimo.setDisponibilidade( rs.getInt( 3 ) );
                requisicaoEmprestimo.setPk_requisicao( rs.getInt( 4 ) );
                requisicaoEmprestimo.setEstudante( requisicaoEmprestimo.getEstudante() + " (" + rs.getString( 5 ) + ")" );
                requisicaoEmprestimo.setFk_livro( rs.getInt( 6 ) );
                requisicaoEmprestimo.setData_devolucao( rs.getDate( 7 ) );

                listaRequisicao.add( requisicaoEmprestimo );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
        return listaRequisicao;
    }

    public void confirmarEmprestimo( int pk_requisicao, int fk_funcionario, int quantidade, int pk_livro ) {
        String queryReq = "update requisicao set estado=?, fk_funcionario=? where pk_requisicao=?";
        String queryLivro = "update livro set quantidade=? where pk_livro=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps1 = con.prepareStatement( queryReq );
            PreparedStatement ps2 = con.prepareStatement( queryLivro );

            ps1.setString( 1, "aceite" );
            ps1.setInt( 2, fk_funcionario );
            ps1.setInt( 3, pk_requisicao );

            int atualizado = quantidade - 1;

            ps2.setInt( 1, atualizado );
            ps2.setInt( 2, pk_livro );

            ps1.execute();
            ps1.close();

            ps2.execute();
            ps2.close();

            con.close();

        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
    }

    public void negarEmprestimo( int pk_requisicao, int fk_funcionario ) {
        String queryReq = "update requisicao set estado=?, fk_funcionario=? where pk_requisicao=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps1 = con.prepareStatement( queryReq );

            ps1.setString( 1, "rejeitado" );
            ps1.setInt( 2, fk_funcionario );
            ps1.setInt( 3, pk_requisicao );

            ps1.execute();
            ps1.close();

            con.close();

        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
    }

    public void devolverEmprestimo( int pk_requisicao, int quantidade, int pk_livro ) {
        String queryReq = "update requisicao set estado=? where pk_requisicao=?";
        String queryLivro = "update livro set quantidade=? where pk_livro=?";
        
        int quantidadeAtualizada = quantidade+1;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps1 = con.prepareStatement( queryReq );
            PreparedStatement ps2 = con.prepareStatement( queryLivro );

            ps1.setString( 1, "devolvido" );
            ps1.setInt( 2, pk_requisicao );
            
            ps2.setInt( 1, quantidadeAtualizada );
            ps2.setInt( 2, pk_livro );

            ps1.execute();
            ps1.close();
            
            ps2.execute();
            ps2.close();

            con.close();

        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
    }

    public void devolverEmprestimoAtrasado( int pk_requisicao, int quantidade, int pk_livro ) {
        String queryReq = "update requisicao set estado=? where pk_requisicao=?";
        String queryLivro = "update livro set quantidade=? where pk_livro=?";
        
        int quantidadeAtualizada = quantidade+1;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps1 = con.prepareStatement( queryReq );
            PreparedStatement ps2 = con.prepareStatement( queryLivro );

            ps1.setString( 1, "devolvido_atrasado" );
            ps1.setInt( 2, pk_requisicao );
            
            ps2.setInt( 1, quantidadeAtualizada );
            ps2.setInt( 2, pk_livro );

            ps1.execute();
            ps1.close();
            
            ps2.execute();
            ps2.close();

            con.close();

        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
    }

    public int getPkFuncionarioDeLoginID( int pk_login ) {

        int pk_funcionario = 0;

        String query = "SELECT pk_funcionario FROM funcionario WHERE fk_login=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );

            ps.setInt( 1, pk_login );

            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                pk_funcionario = rs.getInt( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

        //JOptionPane.showMessageDialog(null, "KKKKentrou: " + pk_login + " JJJJ: " + pk_funcionario);
        return pk_funcionario;

    }

}
