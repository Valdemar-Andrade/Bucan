/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.ResultadoPesquisaHome;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class PesquisasDAO {
    
    public ArrayList<ResultadoPesquisaHome> pesquisaLivroByTitulo(String dadoPesquisa){
        
        ArrayList<ResultadoPesquisaHome> resultadoPesquisa = new ArrayList<>();
        String query = "select titulo, autor, descricao from livro where titulo ilike '%?%'";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString( 1, dadoPesquisa);
            
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ResultadoPesquisaHome resultado = new ResultadoPesquisaHome();

                resultado.setTitulo( rs.getString( 1));
                resultado.setAutor(rs.getString( 2));
                resultado.setDescricao(rs.getString( 3));

                resultadoPesquisa.add(resultado);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return resultadoPesquisa;
    }
    
    public ArrayList<ResultadoPesquisaHome> pesquisaLivroByAutor(String dadoPesquisa){
        
        ArrayList<ResultadoPesquisaHome> resultadoPesquisa = new ArrayList<>();
        String query = "select titulo, autor, descricao from livro where autor ilike '%?%'";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString( 1, dadoPesquisa);
            
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ResultadoPesquisaHome resultado = new ResultadoPesquisaHome();

                resultado.setTitulo( rs.getString( 1));
                resultado.setAutor(rs.getString( 2));
                resultado.setDescricao(rs.getString( 3));

                resultadoPesquisa.add(resultado);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return resultadoPesquisa;
    }
    
    public ArrayList<ResultadoPesquisaHome> pesquisaLivroByGenero(String dadoPesquisa){
        
        ArrayList<ResultadoPesquisaHome> resultadoPesquisa = new ArrayList<>();
        String query = "select l.titulo, l.autor, l.descricao from livro l join categoria c on l.fk_categoria=c.pk_categoria where c.descricao ilike '%?%';";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString( 1, dadoPesquisa);
            
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ResultadoPesquisaHome resultado = new ResultadoPesquisaHome();

                resultado.setTitulo( rs.getString( 1));
                resultado.setAutor(rs.getString( 2));
                resultado.setDescricao(rs.getString( 3));

                resultadoPesquisa.add(resultado);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return resultadoPesquisa;
    }
    
}
