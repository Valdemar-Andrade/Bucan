/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Contacto;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class ContactoDAO {
    
    public void cadastrarContacto(Contacto contacto) {

        String query_insert = "INSERT INTO contacto VALUES (DEFAULT, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, contacto.getDescricao());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Contacto> listarContactos() {
        ArrayList<Contacto> listaContacto = new ArrayList<>();
        String query = "SELECT pk_contacto, descricao FROM contacto";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Contacto contacto = new Contacto();

                contacto.setPk_contacto(rs.getInt(1));
                contacto.setDescricao(rs.getString(2));

                listaContacto.add(contacto);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaContacto;
    }

    public Contacto pegarUltimoContacto() {

        Contacto contacto = new Contacto();

        String query = "SELECT max(pk_contacto) FROM contacto";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                contacto.setPk_contacto(rs.getInt(1));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return contacto;

    }

    public Contacto getContacto(int pk_contacto) {

        Contacto contacto = new Contacto();

        String query = "SELECT pk_contacto, descricao FROM contacto WHERE pk_contacto=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk_contacto);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                contacto.setPk_contacto(rs.getInt(1));
                contacto.setDescricao(rs.getString(2));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return contacto;
    }
    
}
