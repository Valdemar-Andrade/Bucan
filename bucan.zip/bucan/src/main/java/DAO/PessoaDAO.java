/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Perfil;
import Modelo.Pessoa;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class PessoaDAO {
    
    public void cadastrarPessoa(Pessoa pessoa) {

        String query_insert = "INSERT INTO pessoa VALUES (DEFAULT, ?, ?, ?, ?)";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, pessoa.getNome());
            ps.setString(2, pessoa.getNumeroBI());
            ps.setDate(3, pessoa.getDataNascimento());
            ps.setInt(4, pessoa.getFk_contacto());
            
            ps.execute();

            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void editarPessoa(Pessoa pessoa){
        String query = "update pessoa set nome=?, dataNascimento=?, num_bi=? where pk_pessoa=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, pessoa.getNome());
            ps.setDate(2, pessoa.getDataNascimento());
            ps.setString(3, pessoa.getNumeroBI());
            ps.setInt(4, pessoa.getPk_pessoa());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public ArrayList<Pessoa> listarPessoa() {
        ArrayList<Pessoa> pessoas = new ArrayList<>();
        String query = "SELECT pk_pessoa, nome, dataNascimento, num_bi, fk_contacto FROM pessoa";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Pessoa pessoa = new Pessoa();

                pessoa.setPk_pessoa(rs.getInt(1));
                pessoa.setNome(rs.getString(2));
                pessoa.setDataNascimento(rs.getDate(3));
                pessoa.setNumeroBI(rs.getString(4));
                pessoa.setFk_contacto(rs.getInt(5));

                pessoas.add(pessoa);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return pessoas;
    }
    
    public int getPkUltimaPessoa(){
        int pk_pessoa = 0;
        
        String query = "SELECT MAX(pk_pessoa) FROM pessoa";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pk_pessoa = rs.getInt(1);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        
        return pk_pessoa;
    }
    
    public Perfil getPerfilDeLogin(int pk_login) {

        Perfil perfil = new Perfil();
        ResultSet rs;

        //pk_pessoa, fk_usuario, nome
        String query = "SELECT p.pk_pessoa, lo.pk_login, p.nome, l.numero_estudante FROM pessoa p JOIN leitor l ON p.pk_pessoa=l.fk_pessoa JOIN login lo ON lo.pk_login=l.fk_login WHERE pk_login=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setInt(1, pk_login);

            rs = ps.executeQuery();

            if (rs.next()) {
                perfil.setPk_pessoa(rs.getInt(1));
                perfil.setLoginID(rs.getInt(2));
                perfil.setNome(rs.getString(3));
                perfil.setNumeroEstudante(rs.getString(4));
                

                ps.close();
                rs.close();
                con.close();
            }

        } catch (SQLException ex) {
            ex.getMessage();
        }

        //JOptionPane.showMessageDialog(null, pessoa.toString());
        return perfil;

    }
    
    public Perfil getPerfilDeLoginFuncionario(int pk_login) {

        Perfil perfil = new Perfil();
        ResultSet rs;

        //pk_pessoa, fk_usuario, nome
        String query = "SELECT p.pk_pessoa, lo.pk_login, p.nome FROM pessoa p JOIN funcionario f ON p.pk_pessoa=f.fk_pessoa JOIN login lo ON lo.pk_login=f.fk_login WHERE lo.pk_login=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setInt(1, pk_login);

            rs = ps.executeQuery();

            if (rs.next()) {
                perfil.setPk_pessoa(rs.getInt(1));
                perfil.setLoginID(rs.getInt(2));
                perfil.setNome(rs.getString(3));
                

                ps.close();
                rs.close();
                con.close();
            }

        } catch (SQLException ex) {
            ex.getMessage();
        }

        //JOptionPane.showMessageDialog(null, pessoa.toString());
        return perfil;

    }
    
}
