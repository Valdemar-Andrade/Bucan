/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Faculdade;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class FaculdadeDAO {
    
    public boolean cadastrarFaculdade(Faculdade faculdade) {
        
        String query_insert = "INSERT INTO faculdade VALUES (DEFAULT, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, faculdade.getDescricao());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void editarFaculdade(int id, String valor){
        String query = "update faculdade set descricao=? where pk_faculdade=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarFaculdade(int id){
        String query = "delete from faculdade where pk_faculdade=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Faculdade> listarFaculdade() {
        ArrayList<Faculdade> listaFaculdade = new ArrayList<>();
        String query = "SELECT pk_faculdade, descricao FROM faculdade";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Faculdade faculdade = new Faculdade();

                faculdade.setPk_faculdade(rs.getInt(1));
                faculdade.setDescricao(rs.getString(2));

                listaFaculdade.add(faculdade);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaFaculdade;
    }
    
}
