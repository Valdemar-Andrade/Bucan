/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Editora;
import Modelo.EditoraView;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class EditoraDAO {
    
    public void cadastrarEditora(Editora editora) {

        String query_insert = "INSERT INTO editora VALUES (DEFAULT, ?, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, editora.getNome());
            ps.setInt(2, editora.getFk_contacto());
            ps.setInt(3, editora.getFk_endereco());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<EditoraView> listarEditora() {
        ArrayList<EditoraView> listaEditora = new ArrayList<>();
        String query = "SELECT pk_editora, nome, c.descricao, en.descricao FROM editora e JOIN contacto c ON e.fk_contacto=c.pk_contacto JOIN endereco en ON e.fk_endereco=en.pk_endereco";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                EditoraView editora = new EditoraView();

                editora.setPk_editora(rs.getInt(1));
                editora.setNome(rs.getString(2));
                editora.setContacto(rs.getString(3));
                editora.setEndereco(rs.getString(4));

                listaEditora.add(editora);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaEditora;
    }
    
    public void editarEditora(int id, String valor){
        String query = "update editora set nome=? where pk_editora=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarEditora(int id){
        String query = "delete from editora where pk_editora=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
}
