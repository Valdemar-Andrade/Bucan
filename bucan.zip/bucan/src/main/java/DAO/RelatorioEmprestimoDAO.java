/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.RelatorioEmprestimo;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class RelatorioEmprestimoDAO {
    
    public ArrayList<RelatorioEmprestimo> relatorioEmprestimo() {
        ArrayList<RelatorioEmprestimo> relatorioEmprestimo = new ArrayList<>();
        String query = "SELECT pe.nome AS funcionario, li.titulo, pe_leitor.nome AS leitor, COUNT(*) AS quantidade_requisicoes FROM requisicao re JOIN funcionario fu ON fu.pk_funcionario = re.fk_funcionario JOIN pessoa pe ON pe.pk_pessoa = fu.fk_pessoa JOIN leitor le ON le.pk_leitor = re.fk_leitor JOIN pessoa pe_leitor ON pe_leitor.pk_pessoa = le.fk_pessoa JOIN livro li ON li.pk_livro = re.fk_livro GROUP BY pe.nome, li.titulo, pe_leitor.nome";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                RelatorioEmprestimo relatorio = new RelatorioEmprestimo();

                relatorio.setFuncionario(rs.getString(1));
                relatorio.setLivro(rs.getString(2));
                relatorio.setLeitor( rs.getString(3) );
                relatorio.setTotal( rs.getInt(4) );

                relatorioEmprestimo.add(relatorio);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return relatorioEmprestimo;
    }
    
    public ArrayList<RelatorioEmprestimo> relatorioEmprestimoFuncionario() {
        ArrayList<RelatorioEmprestimo> relatorioEmprestimo = new ArrayList<>();
        String query = "SELECT pe.nome AS funcionario, COUNT(*) AS quantidade_atendimentos FROM requisicao re JOIN funcionario fu ON fu.pk_funcionario = re.fk_funcionario JOIN pessoa pe ON pe.pk_pessoa = fu.fk_pessoa GROUP BY pe.nome;";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                RelatorioEmprestimo relatorio = new RelatorioEmprestimo();

                relatorio.setFuncionario(rs.getString(1));
                relatorio.setTotal( rs.getInt(2) );

                relatorioEmprestimo.add(relatorio);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return relatorioEmprestimo;
    }
    
}
