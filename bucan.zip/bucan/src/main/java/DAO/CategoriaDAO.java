/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Categoria;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class CategoriaDAO {
    
    public void cadastrarCategoria(Categoria categoria) {

        String query_insert = "INSERT INTO categoria VALUES (DEFAULT, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, categoria.getDescricao());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Categoria> listarCategoria() {
        ArrayList<Categoria> listaCategoria = new ArrayList<>();
        String query = "SELECT pk_categoria, descricao FROM categoria";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Categoria categoria = new Categoria();

                categoria.setPk_categoria(rs.getInt(1));
                categoria.setDescricao(rs.getString(2));

                listaCategoria.add(categoria);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaCategoria;
    }
    
    public void editarCategoria(int id, String valor){
        String query = "update categoria set descricao=? where pk_categoria=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, valor);
            ps.setInt(2, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminarCategoria(int id){
        String query = "delete from categoria where pk_categoria=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
}
