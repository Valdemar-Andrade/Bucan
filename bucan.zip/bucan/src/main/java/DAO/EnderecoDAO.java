/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Endereco;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class EnderecoDAO {
    
    public void cadastrarEndereco(Endereco endereco) {

        String query_insert = "INSERT INTO endereco VALUES (DEFAULT, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, endereco.getDescricao());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Endereco> listarEndereco() {
        ArrayList<Endereco> listaEndereco = new ArrayList<>();
        String query = "SELECT pk_endereco, descricao FROM endereco";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Endereco endereco = new Endereco();

                endereco.setPk_endereco(rs.getInt(1));
                endereco.setDescricao(rs.getString(2));

                listaEndereco.add(endereco);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaEndereco;
    }

    public Endereco pegarUltimoEndereco() {

        Endereco endereco = new Endereco();

        String query = "SELECT max(pk_endereco) FROM endereco";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                endereco.setPk_endereco(rs.getInt(1));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return endereco;

    }

    public Endereco getEndereco(int pk_endereco) {

        Endereco endereco = new Endereco();

        String query = "SELECT pk_endereco, descricao FROM endereco WHERE pk_endereco=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk_endereco);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                endereco.setPk_endereco(rs.getInt(1));
                endereco.setDescricao(rs.getString(2));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return endereco;
    }
    
}
