/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Leitor;
import Modelo.LeitorView;
import Modelo.Perfil;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class LeitorDAO {

    public void cadastrarLeitor( Leitor leitor ) {

        String query_insert = "INSERT INTO leitor VALUES (DEFAULT, ?, ?, ?, ?, ?, ?)";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query_insert );

            ps.setInt( 1, leitor.getFk_pessoa() );
            ps.setString( 2, leitor.getNumeroEstudante() );
            ps.setString( 3, leitor.getEmailUniversitario() );
            ps.setBoolean( 4, leitor.isEhEstudanteLocal() );
            ps.setInt( 5, leitor.getFk_login() );
            ps.setInt( 6, leitor.getFk_curso() );

            ps.execute();

            ps.close();
            con.close();

        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
    }

    public ArrayList<Leitor> listarLeitor() {
        ArrayList<Leitor> leitores = new ArrayList<>();
        String query = "SELECT pk_leitor, fk_pessoa, numero_estudante, emailUniversitario, ehEstudanteLocal, fk_login, fk_curso FROM leitor";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ResultSet rs = ps.executeQuery();

            while ( rs.next() ) {
                Leitor leitor = new Leitor();

                leitor.setPk_leitor( rs.getInt( 1 ) );
                leitor.setFk_pessoa( rs.getInt( 2 ) );
                leitor.setNumeroEstudante( rs.getString( 3 ) );
                leitor.setEmailUniversitario( rs.getString( 4 ) );
                leitor.setEhEstudanteLocal( rs.getBoolean( 5 ) );
                leitor.setFk_login( rs.getInt( 6 ) );
                leitor.setFk_curso( rs.getInt( 7 ) );

                leitores.add( leitor );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
        return leitores;
    }

    public ArrayList<LeitorView> listarLeitorView() {
        ArrayList<LeitorView> leitores = new ArrayList<>();
        String query = "select le.pk_leitor, pe.nome, le.numero_estudante, cu.descricao, le.fk_login, le.fk_curso, le.fk_pessoa from leitor le join pessoa pe on pe.pk_pessoa=le.fk_pessoa join curso cu on cu.pk_curso=le.fk_curso";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ResultSet rs = ps.executeQuery();

            while ( rs.next() ) {
                LeitorView leitor = new LeitorView();

                leitor.setPk_leitor( rs.getInt( 1 ) );
                leitor.setNome( rs.getString( 2 ) );
                leitor.setNumero( rs.getString( 3 ) );
                leitor.setCurso( rs.getString( 4 ) );
                leitor.setFk_login( rs.getInt( 5 ) );
                leitor.setFk_curso( rs.getInt( 6 ) );
                leitor.setFk_pessoa( rs.getInt( 7 ) );

                leitores.add( leitor );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }
        return leitores;
    }

    public void eliminarLeitor( int pk_leitor, int fk_login, int fk_pessoa, int fk_curso ) {

        String queryLeitor = "delete from leitor where pk_leitor=?";
        String queryLogin = "delete from login where pk_login=?";
        String queryPessoa = "delete from pessoa where pk_pessoa=?";
        String queryCurso = "delete from curso where pk_curso=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps1 = con.prepareStatement( queryLeitor );
            PreparedStatement ps2 = con.prepareStatement( queryLogin );
            PreparedStatement ps3 = con.prepareStatement( queryPessoa );
            PreparedStatement ps4 = con.prepareStatement( queryCurso );

            ps1.setInt( 1, pk_leitor );
            ps1.execute();
            ps1.close();

            ps2.setInt( 1, fk_login );
            ps2.execute();
            ps2.close();

            ps3.setInt( 1, fk_pessoa );
            ps3.execute();
            ps3.close();

            ps4.setInt( 1, fk_curso );
            ps4.execute();
            ps4.close();

            con.close();

        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

    }

    public int totalLeitores() {

        int total = 0;

        String query = "SELECT count(pk_leitor) FROM leitor";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                total = rs.getInt( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

        return total;

    }

    public Perfil getDadosPerfilEstudante( int pk_login ) {

        //select pe.nome, le.numero_estudante, cu.descricao from leitor le join pessoa pe on le.fk_pessoa=pe.pk_pessoa join login lo on lo.pk_login=le.fk_login join curso cu on cu.pk_curso=le.fk_curso where le.fk_login=1;
        String query = "select pe.nome, le.numero_estudante, cu.descricao, le.pk_leitor, lo.email from leitor le join pessoa pe on le.fk_pessoa=pe.pk_pessoa join login lo on lo.pk_login=le.fk_login join curso cu on cu.pk_curso=le.fk_curso where le.fk_login=?";
        Perfil perfil = new Perfil();

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ps.setInt( 1, pk_login );

            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                perfil.setNome( rs.getString( 1 ) );
                perfil.setNumeroEstudante( rs.getString( 2 ) );
                perfil.setCurso( rs.getString( 3 ) );
                perfil.setFk_leitor( rs.getInt( 4 ) );
                perfil.setEmail( rs.getString( 5 ) );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

        return perfil;

    }

    private int getPkLeitorByLoginID( int pk_login ) {

        //select pe.nome, le.numero_estudante, cu.descricao from leitor le join pessoa pe on le.fk_pessoa=pe.pk_pessoa join login lo on lo.pk_login=le.fk_login join curso cu on cu.pk_curso=le.fk_curso where le.fk_login=1;
        String query = "select pk_leitor from leitor where fk_login=?";
        int pk_leitor = 0;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ps.setInt( 1, pk_login );

            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                pk_leitor = rs.getInt( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

        return pk_leitor;

    }

    private int getPkCursoLeitorByLoginID( int pk_login ) {

        //select pe.nome, le.numero_estudante, cu.descricao from leitor le join pessoa pe on le.fk_pessoa=pe.pk_pessoa join login lo on lo.pk_login=le.fk_login join curso cu on cu.pk_curso=le.fk_curso where le.fk_login=1;
        String query = "select fk_curso from leitor where fk_login=?";
        int pk_curso = 0;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ps.setInt( 1, pk_login );

            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                pk_curso = rs.getInt( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

        return pk_curso;

    }

    private int getPkPessoaLeitorByLoginID( int pk_login ) {

        //select pe.nome, le.numero_estudante, cu.descricao from leitor le join pessoa pe on le.fk_pessoa=pe.pk_pessoa join login lo on lo.pk_login=le.fk_login join curso cu on cu.pk_curso=le.fk_curso where le.fk_login=1;
        String query = "select fk_pessoa from leitor where fk_login=?";
        int pk_pessoa = 0;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );
            ps.setInt( 1, pk_login );

            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                pk_pessoa = rs.getInt( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

        return pk_pessoa;

    }

    public void editarDadosLeitor( String nome, String numero, String curso, int pk_login ) {

        int pk_leitor = getPkLeitorByLoginID( pk_login );
        int pk_curso = getPkCursoLeitorByLoginID( pk_login );
        int pk_pessoa = getPkPessoaLeitorByLoginID( pk_login );

        String queryNumero = "update leitor set numero_estudante=? where pk_leitor=?";
        String queryCurso = "update curso set descricao=? where pk_curso=?";
        String queryNome = "update pessoa set nome=? where pk_pessoa=?";

        try {
            Connection con = Conexao.abrirConexao();

            PreparedStatement psNumero = con.prepareStatement( queryNumero );
            PreparedStatement psCurso = con.prepareStatement( queryCurso );
            PreparedStatement psNome = con.prepareStatement( queryNome );

            psNumero.setString( 1, numero );
            psNumero.setInt( 2, pk_leitor );

            psCurso.setString( 1, curso );
            psCurso.setInt( 2, pk_curso );

            psNome.setString( 1, nome );
            psNome.setInt( 2, pk_pessoa );

            psNumero.execute();
            psNumero.close();

            psCurso.execute();
            psCurso.close();

            psNome.execute();
            psNome.close();

            con.close();

        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

    }

    public int getPkLeitorFromNumeroEstudante( String numero_estudante ) {

        String query = "select pk_leitor from leitor where numero_estudante=?";

        int pk_leitor = 0;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );

            ps.setString( 1, numero_estudante );

            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                pk_leitor = rs.getInt( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

        return pk_leitor;

    }

    public boolean isLeitorLocal( int pk_login ) {

        String query = "select \"ehEstudanteLocal\" from leitor where fk_login=?";

        boolean isLocal = false;

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement( query );

            ps.setInt( 1, pk_login );

            ResultSet rs = ps.executeQuery();

            if ( rs.next() ) {
                isLocal = rs.getBoolean( 1 );
            }
        }
        catch ( SQLException ex ) {
            ex.getMessage();
        }

        return isLocal;
    }

}
