/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Mensagem;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author valdemar
 */
public class MensagemDAO {
    
    public void cadastrarMensagem(Mensagem mensagem) {

        String query_insert = "INSERT INTO mensagens VALUES (DEFAULT, ?, ?, ?, ?)";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setString(1, mensagem.getNome());
            ps.setString(2, mensagem.getEmail());
            ps.setString(3, mensagem.getMensagem());
            ps.setInt(4, mensagem.getFk_leitor());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<Mensagem> listarMensagens() {
        ArrayList<Mensagem> listaMensagens = new ArrayList<>();
        String query = "SELECT pk_mensagem, nome, email, mensagem, fk_leitor FROM mensagens order by pk_mensagem desc";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Mensagem msg = new Mensagem();

                msg.setPk_mensagem(rs.getInt(1));
                msg.setNome(rs.getString(2));
                msg.setEmail(rs.getString(3));
                msg.setMensagem(rs.getString(4));
                msg.setFk_leitor(rs.getInt(5));

                listaMensagens.add(msg);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return listaMensagens;
    }
    
    public void eliminarMensagem(int id){
        String query = "delete from mensagens where pk_mensagem=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
}
